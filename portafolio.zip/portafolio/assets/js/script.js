// Fondo de partículas (particles.js)
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('particles-js') && window.particlesJS) {
        particlesJS('particles-js', {
            particles: {
                number: { value: 80, density: { enable: true, value_area: 800 } },
                color: { value: "#00ff00" },
                shape: { type: "circle" },
                opacity: { value: 0.5, random: true },
                size: { value: 3, random: true },
                line_linked: { enable: true, distance: 150, color: "#00ff00", opacity: 0.4, width: 1 },
                move: { enable: true, speed: 2, direction: "none", random: true, straight: false, out_mode: "out" }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "repulse" },
                    onclick: { enable: true, mode: "push" }
                }
            }
        });
    }
});
// Cursor personalizado mejorado
document.addEventListener('DOMContentLoaded', () => {
    const cursorInner = document.querySelector('.cursor-inner');
    const cursorOuter = document.querySelector('.cursor-outer');
    if (cursorInner && cursorOuter) {
        document.addEventListener('mousemove', (e) => {
            cursorInner.style.transform = `translate3d(calc(${e.clientX}px - 50%), calc(${e.clientY}px - 50%), 0)`;
            cursorOuter.style.transform = `translate3d(calc(${e.clientX}px - 50%), calc(${e.clientY}px - 50%), 0)`;
        });

        const interactiveElements = document.querySelectorAll('a, button, .item, .pixel-btn, .pixel-social, input, textarea, [data-spa-link]');
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursorInner.classList.add('cursor-hover');
                cursorOuter.classList.add('cursor-hover-outer');
            });
            el.addEventListener('mouseleave', () => {
                cursorInner.classList.remove('cursor-hover');
                cursorOuter.classList.remove('cursor-hover-outer');
            });
        });
    }
});

import { inyectBlogPage } from './blog.js';
import { inyectHomePage, initHomePage } from './dashboard.js';

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar la página principal
    inyectHomePage().then(() => {
        console.log('Dashboard cargado correctamente');
    }).catch(error => {
        console.error('Error al cargar dashboard:', error);
    });
    // También puedes usar initHomePage directamente si el HTML ya está presente
    // initHomePage();
});

// Para cargar el blog
document.addEventListener('DOMContentLoaded', () => {
    // Si estás en la ruta del blog
    if (window.location.pathname.includes('/blog')) {
        inyectBlogPage();
    }
});