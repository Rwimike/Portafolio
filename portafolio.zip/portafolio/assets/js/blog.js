// blog.js - Módulo para manejar el blog de programación

// Datos de ejemplo para los posts (en una app real esto vendría de una API)
const samplePosts = [
    {
        id: 1,
        title: 'Cómo crear efectos CSS estilo videojuego',
        category: 'web',
        content: 'En este artículo exploraremos cómo crear efectos visuales impresionantes usando solo CSS, inspirados en los videojuegos clásicos de los 80s y 90s.\n\n```css\n.pixel-border {\n    border: 4px solid #00ff00;\n    position: relative;\n}\n```',
        date: '2023-05-15'
    },
    {
        id: 2,
        title: 'Introducción a Pygame para desarrollo de juegos',
        category: 'game',
        content: 'Pygame es una biblioteca fantástica para comenzar en el desarrollo de juegos con Python. Aquí te muestro los conceptos básicos para empezar:\n\n1. Configuración inicial\n2. Manejo de sprites\n3. Detección de colisiones\n4. Sistema de sonido\n\nEjemplo básico:\n\n```python\nimport pygame\npygame.init()\nscreen = pygame.display.set_mode((800, 600))\n```',
        date: '2023-06-02'
    }
];

/**
 * Inyecta el template del blog en el contenedor #app
 */
export async function inyectBlogPage() {
    try {
        const template = document.getElementById('blog-template');
        if (!template) {
            throw new Error('Plantilla blog-template no encontrada');
        }
        
        const appContainer = document.querySelector('#app');
        if (appContainer) {
            appContainer.innerHTML = '';
            appContainer.appendChild(template.content.cloneNode(true));
            initBlogPage();
        }
    } catch (error) {
        console.error('Error al inyectar la página del blog:', error);
        showError('Error al cargar el blog. Por favor, intenta nuevamente.');
    }
}

/**
 * Inicializa la página del blog con todas las funcionalidades
 */
export function initBlogPage() {
    // Configuración inicial
    setupBlogNavigation();
    loadBlogPosts();
    setupBlogControls();
    setupPostModal();
}

/**
 * Configura la navegación entre portafolio/blog
 */
function setupBlogNavigation() {
    const blogSection = document.querySelector('.blog-section');
    if (!blogSection) return;

    const spaMenu = document.createElement('div');
    spaMenu.className = 'spa-menu';
    spaMenu.innerHTML = `
        <a href="/" class="spa-link" data-spa-link>
            <i class="fas fa-home"></i> Portafolio
        </a>
        <a href="/blog" class="spa-link active" data-spa-link>
            <i class="fas fa-blog"></i> Blog
        </a>
    `;
    blogSection.prepend(spaMenu);
}

/**
 * Carga los posts en el contenedor
 */
function loadBlogPosts() {
    const container = document.getElementById('blog-posts-container');
    const template = document.getElementById('post-template');
    
    if (!container || !template) return;

    // Limpiar contenedor
    container.innerHTML = '';

    // Ordenar posts por fecha (más nuevos primero)
    const sortedPosts = [...samplePosts].sort((a, b) => new Date(b.date) - new Date(a.date));

    // Añadir posts al DOM
    sortedPosts.forEach(post => {
        addPostToDOM(post, container, template);
    });
}

/**
 * Añade un post al DOM
 */
function addPostToDOM(post, container, template) {
    const clone = template.content.cloneNode(true);
    const article = clone.querySelector('.blog-post');
    
    // Configurar datos del post
    article.dataset.category = post.category;
    article.dataset.id = post.id;
    clone.querySelector('.post-title').textContent = post.title;
    clone.querySelector('.post-content').innerHTML = formatPostContent(post.content);
    clone.querySelector('.post-date').textContent = new Date(post.date).toLocaleDateString();
    
    // Estilizar según categoría
    stylePostByCategory(article, post.category);
    
    // Configurar botones de acción
    clone.querySelector('.edit-post').addEventListener('click', (e) => {
        e.stopPropagation();
        editPost(post.id);
    });
    
    clone.querySelector('.delete-post').addEventListener('click', (e) => {
        e.stopPropagation();
        deletePost(post.id);
    });
    
    // Ver post completo al hacer clic
    article.addEventListener('click', () => {
        viewPost(post);
    });
    
    container.appendChild(clone);
}

/**
 * Formatea el contenido del post (conversión de markdown simple)
 */
function formatPostContent(content) {
    return content.split('\n\n').map(paragraph => {
        // Detectar bloques de código
        if (paragraph.startsWith('```') && paragraph.endsWith('```')) {
            const codeContent = paragraph.slice(3, -3);
            return `<pre><code>${codeContent}</code></pre>`;
        }
        // Párrafos normales
        return `<p>${paragraph}</p>`;
    }).join('');
}

/**
 * Estiliza el post según su categoría
 */
function stylePostByCategory(postElement, category) {
    const categorySpan = postElement.querySelector('.post-category');
    if (!categorySpan) return;
    
    categorySpan.textContent = getCategoryName(category);
    
    switch(category) {
        case 'web':
            postElement.style.borderLeftColor = '#00a8ff';
            categorySpan.style.backgroundColor = 'rgba(0, 168, 255, 0.2)';
            break;
        case 'game':
            postElement.style.borderLeftColor = '#ff5500';
            categorySpan.style.backgroundColor = 'rgba(255, 85, 0, 0.2)';
            break;
        case 'python':
            postElement.style.borderLeftColor = '#4b8bbe';
            categorySpan.style.backgroundColor = 'rgba(75, 139, 190, 0.2)';
            break;
        case 'js':
            postElement.style.borderLeftColor = '#f0db4f';
            categorySpan.style.backgroundColor = 'rgba(240, 219, 79, 0.2)';
            categorySpan.style.color = '#333';
            break;
    }
}

/**
 * Obtiene el nombre legible de la categoría
 */
function getCategoryName(category) {
    const names = {
        'web': 'Web Dev',
        'game': 'Game Dev',
        'python': 'Python',
        'js': 'JavaScript'
    };
    return names[category] || 'General';
}

/**
 * Configura los controles del blog (búsqueda, filtros)
 */
function setupBlogControls() {
    // Filtrado por categoría
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterPosts(btn.dataset.category);
        });
    });
    
    // Búsqueda
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchPosts(e.target.value);
        });
    }
}

/**
 * Filtra posts por categoría
 */
function filterPosts(category) {
    const posts = document.querySelectorAll('.blog-post');
    posts.forEach(post => {
        post.style.display = (category === 'all' || post.dataset.category === category) 
            ? 'block' 
            : 'none';
    });
}

/**
 * Busca posts por texto
 */
function searchPosts(query) {
    const searchTerm = query.toLowerCase();
    const posts = document.querySelectorAll('.blog-post');
    
    posts.forEach(post => {
        const title = post.querySelector('.post-title').textContent.toLowerCase();
        const content = post.querySelector('.post-content').textContent.toLowerCase();
        
        post.style.display = (title.includes(searchTerm) || content.includes(searchTerm)) 
            ? 'block' 
            : 'none';
    });
}

/**
 * Configura el modal para nuevo/editar post
 */
function setupPostModal() {
    const newPostBtn = document.getElementById('new-post-btn');
    const postModal = document.getElementById('post-modal');
    const closeModal = document.querySelector('.close-modal');
    const postForm = document.getElementById('post-form');
    
    if (!newPostBtn || !postModal || !closeModal || !postForm) return;
    
    // Abrir modal
    newPostBtn.addEventListener('click', () => {
        postModal.style.display = 'flex';
        document.getElementById('post-title').focus();
    });
    
    // Cerrar modal
    closeModal.addEventListener('click', () => {
        postModal.style.display = 'none';
        postForm.reset();
        delete postForm.dataset.editingId;
    });
    
    // Cerrar al hacer clic fuera
    postModal.addEventListener('click', (e) => {
        if (e.target === postModal) {
            postModal.style.display = 'none';
            postForm.reset();
            delete postForm.dataset.editingId;
        }
    });
    
    // Manejar envío del formulario
    postForm.addEventListener('submit', (e) => {
        e.preventDefault();
        handlePostFormSubmit();
    });
}

/**
 * Maneja el envío del formulario de post
 */
function handlePostFormSubmit() {
    const title = document.getElementById('post-title').value.trim();
    const category = document.getElementById('post-category').value;
    const content = document.getElementById('post-content').value.trim();
    const postForm = document.getElementById('post-form');
    
    if (!title || !content) {
        showError('Por favor completa todos los campos');
        return;
    }
    
    const postId = postForm.dataset.editingId || Date.now();
    const isEditing = !!postForm.dataset.editingId;
    
    const postData = {
        id: postId,
        title,
        category,
        content,
        date: isEditing ? samplePosts.find(p => p.id == postId).date : new Date().toISOString().split('T')[0]
    };
    
    if (isEditing) {
        // Actualizar post existente
        updatePost(postData);
    } else {
        // Crear nuevo post
        createPost(postData);
    }
    
    // Cerrar modal y resetear formulario
    document.getElementById('post-modal').style.display = 'none';
    postForm.reset();
    delete postForm.dataset.editingId;
}

/**
 * Crea un nuevo post
 */
function createPost(postData) {
    // En una app real, aquí harías una petición a la API
    samplePosts.unshift(postData); // Añadir al inicio del array
    reloadBlogPosts();
}

/**
 * Actualiza un post existente
 */
function updatePost(postData) {
    // En una app real, aquí harías una petición a la API
    const index = samplePosts.findIndex(p => p.id == postData.id);
    if (index !== -1) {
        samplePosts[index] = postData;
        reloadBlogPosts();
    }
}

/**
 * Recarga los posts en el DOM
 */
function reloadBlogPosts() {
    const container = document.getElementById('blog-posts-container');
    const template = document.getElementById('post-template');
    
    if (!container || !template) return;
    
    container.innerHTML = '';
    loadBlogPosts();
}

/**
 * Edita un post existente
 */
function editPost(postId) {
    const post = samplePosts.find(p => p.id == postId);
    if (!post) return;
    
    const postForm = document.getElementById('post-form');
    if (!postForm) return;
    
    // Llenar formulario con datos del post
    document.getElementById('post-title').value = post.title;
    document.getElementById('post-content').value = post.content;
    document.getElementById('post-category').value = post.category;
    
    // Cambiar texto del botón
    postForm.querySelector('button[type="submit"]').textContent = 'Actualizar Post';
    
    // Guardar referencia al post que estamos editando
    postForm.dataset.editingId = postId;
    
    // Mostrar modal
    document.getElementById('post-modal').style.display = 'flex';
}

/**
 * Elimina un post
 */
function deletePost(postId) {
    if (!confirm('¿Estás seguro de eliminar este post?')) return;
    
    // En una app real, aquí harías una petición a la API
    const index = samplePosts.findIndex(p => p.id == postId);
    if (index !== -1) {
        samplePosts.splice(index, 1);
        reloadBlogPosts();
    }
}

/**
 * Muestra un post en vista detallada
 */
function viewPost(post) {
    const postDetail = document.createElement('div');
    postDetail.className = 'post-detail-modal';
    postDetail.innerHTML = `
        <div class="post-detail-content pixel-border">
            <button class="close-detail">&times;</button>
            <h2>${post.title}</h2>
            <div class="post-meta">
                <span class="post-category ${post.category}">${getCategoryName(post.category)}</span>
                <span class="post-date">${new Date(post.date).toLocaleDateString()}</span>
            </div>
            <div class="post-full-content">${formatPostContent(post.content)}</div>
        </div>
    `;
    
    document.body.appendChild(postDetail);
    
    // Configurar evento para cerrar
    postDetail.querySelector('.close-detail').addEventListener('click', () => {
        postDetail.remove();
    });
    
    // Cerrar al hacer clic fuera
    postDetail.addEventListener('click', (e) => {
        if (e.target === postDetail) {
            postDetail.remove();
        }
    });
}

/**
 * Muestra un mensaje de error
 */
function showError(message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message pixel-border';
    errorElement.innerHTML = `
        <p>${message}</p>
        <button class="pixel-btn" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i> Cerrar
        </button>
    `;
    
    document.body.appendChild(errorElement);
    
    // Eliminar automáticamente después de 5 segundos
    setTimeout(() => {
        if (errorElement.parentNode) {
            errorElement.remove();
        }
    }, 5000);
}

// Exportar funciones principales
export default {
    inyectBlogPage,
    initBlogPage
};