// dashboard.js - Módulo para manejar la página principal del portafolio

/**
 * Inicializa la página principal con todas las funcionalidades
 */
export function initHomePage() {
    initProjectFilters();
    initTypingEffects();
    setupEventListeners();
}

/**
 * Inyecta el contenido de la página principal en el contenedor #app
 */
export async function inyectHomePage() {
    try {
        // Obtener el template del DOM (ya que no está en un archivo separado)
        const template = document.getElementById('home-template');
        if (!template) {
            throw new Error('Plantilla home-template no encontrada');
        }
        
        // Clonar el template y agregarlo al DOM
        const appContainer = document.querySelector('#app');
        if (appContainer) {
            appContainer.innerHTML = '';
            appContainer.appendChild(template.content.cloneNode(true));
            initHomePage();
        }
    } catch (error) {
        console.error('Error al inyectar la página principal:', error);
        // Fallback: Mostrar un mensaje de error o contenido por defecto
        const appContainer = document.querySelector('#app');
        if (appContainer) {
            appContainer.innerHTML = `
                <div class="error-message pixel-border">
                    <h2>Error al cargar el contenido</h2>
                    <p>Por favor, recarga la página o intenta más tarde.</p>
                    <button class="pixel-btn" onclick="window.location.reload()">
                        <i class="fas fa-sync-alt"></i> Recargar
                    </button>
                </div>
            `;
        }
    }
}

/**
 * Configura los filtros de proyectos
 */
function initProjectFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectItems = document.querySelectorAll('.inventory-slot');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Actualizar botones activos
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Filtrar proyectos
            const filterValue = button.dataset.filter;
            projectItems.forEach(item => {
                item.style.display = (filterValue === 'all' || item.dataset.category === filterValue) 
                    ? 'block' 
                    : 'none';
            });
            
            // Efecto visual al filtrar
            animateFilterChange();
        });
    });
}

/**
 * Efecto de animación al cambiar filtros
 */
function animateFilterChange() {
    const projectsContainer = document.querySelector('.inventory-grid');
    if (projectsContainer) {
        projectsContainer.style.opacity = '0';
        setTimeout(() => {
            projectsContainer.style.transition = 'opacity 0.3s ease';
            projectsContainer.style.opacity = '1';
        }, 10);
    }
}

/**
 * Inicializa los efectos de escritura
 */
function initTypingEffects() {
    const typingElements = document.querySelectorAll('.typing-effect');
    
    typingElements.forEach(element => {
        const originalText = element.textContent;
        element.textContent = '';
        
        let i = 0;
        const typingSpeed = 20; // ms entre caracteres
        
        const typeWriter = () => {
            if (i < originalText.length) {
                element.textContent += originalText.charAt(i);
                i++;
                setTimeout(typeWriter, typingSpeed);
            }
        };
        
        // Iniciar efecto después de un pequeño retraso para mejor UX
        setTimeout(typeWriter, 500);
    });
}

/**
 * Configura listeners adicionales
 */
function setupEventListeners() {
    // Efectos hover para los proyectos
    const projectItems = document.querySelectorAll('.inventory-slot');
    projectItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            item.style.transform = 'scale(1.05) rotate(2deg)';
            item.style.boxShadow = '0 10px 20px rgba(0, 255, 0, 0.3)';
        });
        
        item.addEventListener('mouseleave', () => {
            item.style.transform = 'scale(1) rotate(0)';
            item.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        });
    });
    
    // Configurar tooltips para proyectos
    setupProjectTooltips();
}

/**
 * Configura tooltips para los proyectos
 */
function setupProjectTooltips() {
    const projects = [
        { selector: '.inventory-slot:nth-child(1)', text: 'Sistema de autenticación con validación' },
        { selector: '.inventory-slot:nth-child(2)', text: 'Sitio multipágina con navegación' },
        { selector: '.inventory-slot:nth-child(3)', text: 'Menú interactivo con animaciones CSS' },
        { selector: '.inventory-slot:nth-child(4)', text: 'Calendario de eventos con JavaScript' },
        { selector: '.inventory-slot:nth-child(5)', text: 'Tienda online con carrito de compras' },
        { selector: '.inventory-slot:nth-child(6)', text: 'Juego de ajedrez con inteligencia artificial básica' }
    ];
    
    projects.forEach(project => {
        const element = document.querySelector(project.selector);
        if (element) {
            const tooltip = document.createElement('div');
            tooltip.className = 'project-tooltip';
            tooltip.textContent = project.text;
            element.appendChild(tooltip);
            
            element.addEventListener('mouseenter', () => {
                tooltip.style.opacity = '1';
                tooltip.style.visibility = 'visible';
            });
            
            element.addEventListener('mouseleave', () => {
                tooltip.style.opacity = '0';
                tooltip.style.visibility = 'hidden';
            });
        }
    });
}

/**
 * Función para recargar la página principal
 */
export function reloadHomePage() {
    const appContainer = document.querySelector('#app');
    if (appContainer) {
        const template = document.getElementById('home-template');
        if (template) {
            appContainer.innerHTML = '';
            appContainer.appendChild(template.content.cloneNode(true));
            initHomePage();
        }
    }
}

// Exportar funciones principales
export default {
    initHomePage,
    inyectHomePage,
    reloadHomePage
};